TUTORIAL: Online File Storage w/ PHP & jQuery
==============================================

Working example in SOURCE folder. Remember to 
change the CHMODE of the uploads/ folder to
accept uploads. Password and file path can be
changed in the settings.php file.

Images are from FamFamFam.com