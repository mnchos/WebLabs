<?php
/**
 * Class Settings holds the upload settings
 *
 */
class Settings
{
	static $password	 = "mypassword";
	static $uploadFolder = "uploads/";
}
?>